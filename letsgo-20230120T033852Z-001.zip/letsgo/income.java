package letsgo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class income extends JPanel {

    int value[] = {46,34,11,8,1};
    String[] label = {"Personal income taxes: 46%", "Social security and medicare taxes: 34%", "Corporate income taxes: 11%", "Excise and customs taxes: 8", "Borrowing to cover deficit: 1%"};
    int start = 90;
    int xpos = 100;
    int sum = 0;  
    Color[] colors = {Color.blue, Color.red, Color.black, Color.gray, Color.pink};
    
    public income() {  
        for(int k = 0; k < value.length; k++)
        {        
        	sum += value[k];
        }    
    }

    public void paintComponent(Graphics g)  {
    	
        for(int i = 0; i < value.length; i++) {
        	System.out.println(value);
            g.setColor(colors[i%colors.length]);
            g.fillArc(10, 10, 360, 360, start, -(value[i]*360)/sum-3);
            g.drawString(label[i], 380, xpos += 15);
            start = start -(value[i]*360)/sum;
        }
    }

    public static void main(String args[]) {
        JFrame f = new JFrame("Income");
        
        income p = new income();

        f.add(p);
        p.setPreferredSize(new Dimension(600, 500));
        f.pack();
        f.setVisible(true);
    }
}