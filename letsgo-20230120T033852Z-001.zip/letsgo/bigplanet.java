package letsgo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class bigplanet extends JPanel {

	    int value[] = {100,10,80,5,31800,9500};
	    String[] label = {"Earth", "Mars",  "Venus", "Mercury", "Jupiter", "Saturn"};
	    int start = 90;
	    int xpos = 100;
	    int sum = 0;  
	    Color[] colors = {Color.blue, Color.red, Color.yellow, Color.red, Color.gray,Color.orange};
	    
	    public bigplanet() {
	    	
	        for(int k = 0; k < value.length; k++)
	        {        
	        	sum += value[k];
	        }    
	    }

	    public void paintComponent(Graphics g)  {
	    	
	        for(int i = 0; i < value.length; i++) {
	        	System.out.println(value);
	            g.setColor(colors[i%colors.length]);
	            g.fillArc(10, 10, 360, 360, start, -(value[i]*360)/sum-3);
	            g.drawString(label[i], 380, xpos += 15);
	            start = start -(value[i]*360)/sum;
	        }
	    }

	    public static void main(String args[])  {
	        JFrame f = new JFrame("Income");
	        
	        bigplanet p = new bigplanet();

	        f.add(p);
	        p.setPreferredSize(new Dimension(600, 500));
	        f.pack();
	        f.setVisible(true);
	    }
	}