package letsgo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class spending extends JPanel {

    int value[] = {20,35,15,10};
    String[] label = {"Ushqim: 20 Euro", "Transport : 35 Euro", "Kafe dhe pije: 15 euro", "Misc. : 10 Euro"};
    int start = 90;
    int xpos = 100;
    int sum = 0;  
    Color[] colors = {Color.green, Color.orange, Color.black, Color.gray};
    
    public spending() {   
        for(int k = 0; k < value.length; k++)
        {        
        	sum += value[k];
        }    
    }

    public void paintComponent(Graphics g)  {
    	
        for(int i = 0; i < value.length; i++) {
        	System.out.println(value);
            g.setColor(colors[i%colors.length]);
            g.fillArc(10, 10, 360, 360, start, -(value[i]*360)/sum-3);
            g.drawString(label[i], 380, xpos += 15);
            start = start -(value[i]*360)/sum;
        }
    }

    public static void main(String args[]) {
        JFrame f = new JFrame("Income");
        
        spending p = new spending();

        f.add(p);
        p.setPreferredSize(new Dimension(600, 500));
        f.pack();
        f.setVisible(true);
    }
}